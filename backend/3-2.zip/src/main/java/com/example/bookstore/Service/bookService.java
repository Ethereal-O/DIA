package com.example.bookstore.Service;
import java.util.List;

public interface bookService {
    public List getallbookdataservice();

    public Integer adminchangedataservice(Integer index, Integer options, String content);

    public Integer addcartservice(Integer bookid,String username);

    public List getusercartdataservice(String username);

    public Integer userdeletecartdataservice(Integer bookid,String username);

    public Integer usercleancartservice(String username);

    public List getusershelfdataservice(String username);
}
