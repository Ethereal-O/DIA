package com.example.bookstore.Service;

public interface logService {
    public Integer checkloginservice(String username,String password);

    public boolean trylogoutservice();

    public Integer registerservice(String username,String password);
}
