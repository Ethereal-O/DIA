package com.example.bookstore.DaoImpl;

import com.example.bookstore.Dao.CartDao;
import com.example.bookstore.Entity.CartEntity;
import com.example.bookstore.Entity.UserEntity;
import com.example.bookstore.Utils.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class CartDaoImpl implements CartDao {
    @Override
    public boolean addCart(CartEntity cart) {
        try {
            Session session= HibernateUtil.getSessionFactory().getCurrentSession();
            session.beginTransaction();
            session.save(cart);
            session.getTransaction().commit();
            return true;
        } catch (HibernateException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateCart(CartEntity cart) {
        try {
            Session session= HibernateUtil.getSessionFactory().getCurrentSession();
            session.beginTransaction();
            session.update(cart);
            session.getTransaction().commit();
            return true;
        } catch (HibernateException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteCart(CartEntity cart) {
        try {
            Session session= HibernateUtil.getSessionFactory().getCurrentSession();
            session.beginTransaction();
            session.delete(cart);
            session.getTransaction().commit();
            return true;
        } catch (HibernateException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public CartEntity findCartById(Integer id) {
        try {
            Session session= HibernateUtil.getSessionFactory().getCurrentSession();
            session.beginTransaction();
            CartEntity cart= (CartEntity) session.get(CartEntity.class, id);
            session.getTransaction().commit();
            return cart;
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<CartEntity> findCartByExample(CartEntity cart) {
        try {
            Session session= HibernateUtil.getSessionFactory().getCurrentSession();
            session.beginTransaction();
            Criteria criteria = session.createCriteria(CartEntity.class);
            criteria.add(Example.create(cart));
            List<CartEntity> cartdata = criteria.list();
            session.getTransaction().commit();
            return cartdata;
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<CartEntity> findallCart() {
        try {
            Session session= HibernateUtil.getSessionFactory().getCurrentSession();
            session.beginTransaction();
            Criteria criteria = session.createCriteria(CartEntity.class);
            List<CartEntity> cartdata = criteria.list();
            session.getTransaction().commit();
            return cartdata;
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        }
    }
}
