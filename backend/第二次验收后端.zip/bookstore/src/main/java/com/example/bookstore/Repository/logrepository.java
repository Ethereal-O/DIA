package com.example.bookstore.Repository;

import com.example.bookstore.Entity.BookEntity;
import com.example.bookstore.Entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface logrepository extends JpaRepository<UserEntity,Integer> {

    @Query(value = "from UserEntity ")
    List<UserEntity> getusers();

    @Modifying
    @Transactional
    @Query(value = "insert into user(username,password) values (:username,:password)",nativeQuery = true)
    void register(String username,String password);
}
