package com.example.bookstore.Repository;

import com.example.bookstore.Entity.BookEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
@Repository
public interface bookrepository extends JpaRepository<BookEntity,Integer> {

    @Query(value = "from BookEntity ")
    List<BookEntity> getallbookdata();

    @Modifying
    @Transactional
    @Query(value = "update BookEntity set name=:content where id=:index")
    void adminchangename(int index,String content);

    @Modifying
    @Transactional
    @Query(value = "update BookEntity set author=:content where id=:index")
    void adminchangeauthor(int index,String content);

    @Modifying
    @Transactional
    @Query(value = "update BookEntity set price=:content where id=:index")
    void adminchangeprice(int index,String content);

    @Modifying
    @Transactional
    @Query(value = "update BookEntity set description=:content where id=:index")
    void adminchangedescription(int index,String content);

    @Modifying
    @Transactional
    @Query(value = "insert into cart(uid,bid) values ((select id from user where user.username=:username),:bookid)",nativeQuery = true)
    void addcart(int bookid,String username);

    @Query(value = "select * from book where id in (select cart.bid from cart,user where cart.uid=user.id and user.username = :username)",nativeQuery = true)
    List<BookEntity> getusercartdata(String username);

    @Modifying
    @Transactional
    @Query(value = "delete from cart where cart.uid=(select id from user where user.username=:username) and bid=:bookid",nativeQuery = true)
    void userdeletecartdata(int bookid,String username);

    @Modifying
    @Transactional
    @Query(value = "insert into `order`(uid) (select id from user where user.username=:username)",nativeQuery = true)
    void usersetneworder(String username);

    @Query(value ="select last_insert_id()",nativeQuery = true)
    Integer getneworderid();

    @Modifying
    @Transactional
    @Query(value = "insert into `orderitem`(oid,bid) values (:orderid,:bookid)",nativeQuery = true)
    void usersetneworderitem(Integer orderid,Integer bookid);

    @Query(value = "select * from `book` where id in (select `orderitem`.bid from `order`,`orderitem`,`user` where `order`.uid=`user`.id and `order`.id=`orderitem`.oid and `user`.username = :username)",nativeQuery = true)
    List<BookEntity> getusershelfdata(String username);

}
