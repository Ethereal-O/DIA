package com.example.bookstore.Entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "cart", schema = "mybookstore", catalog = "")
public class CartEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Basic
    @Column(name = "uid")
    private int uid;
    @Basic
    @Column(name = "bid")
    private int bid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartEntity that = (CartEntity) o;
        return id == that.id && uid == that.uid && bid == that.bid;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, uid, bid);
    }
}
