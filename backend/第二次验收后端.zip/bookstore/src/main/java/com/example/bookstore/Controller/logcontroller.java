package com.example.bookstore.Controller;

import com.example.bookstore.Entity.UserEntity;
import com.example.bookstore.Repository.logrepository;
import com.example.bookstore.Utils.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

@CrossOrigin(origins = "http://localhost:3000", maxAge = 3000)
@RestController
public class logcontroller {

    @Autowired
    logrepository loguserrepository;

    @RequestMapping("/checkloginservice")
    public Integer checkloginservice(@RequestParam(name = "username")String username, @RequestParam(name = "password")String password){
        List<UserEntity> users=loguserrepository.getusers();
        for (int i=0;i<users.size();i++)
        {
            if (Objects.equals(users.get(i).getUsername(), username))
            {
                if (Objects.equals(users.get(i).getPassword(), password))
                {
                    SessionUtil.SetSession(users.get(i).getId(),users.get(i).getType());
                    return users.get(i).getType();
                }else{
                    return 0;
                }
            }
        }
        return -1;
    }

    @RequestMapping("/trylogoutservice")
    public boolean trylogoutservice(){
        return SessionUtil.RemoveSession();
    }

    @RequestMapping("/registerservice")
    public Integer registerservice(@RequestParam(name = "username")String username, @RequestParam(name = "password")String password)
    {
        List<UserEntity> users=loguserrepository.getusers();
        for (int i=0;i<users.size();i++)
        {
            if (Objects.equals(users.get(i).getUsername(), username))
            {
                return 0;
            }
        }
        loguserrepository.register(username, password);
        return 1;
    }
}