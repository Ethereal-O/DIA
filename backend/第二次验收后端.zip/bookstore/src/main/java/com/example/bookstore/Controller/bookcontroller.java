package com.example.bookstore.Controller;
import com.example.bookstore.Entity.BookEntity;
import com.example.bookstore.Repository.bookrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.In;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.awt.print.Book;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000", maxAge = 3000)
@RestController
public class bookcontroller {
    @Autowired
    bookrepository bookstorerepository;

    @RequestMapping("/getallbookdataservice")
    public List getallbookdataservice(){
        List<List> data=new ArrayList<>();
        List<BookEntity> bookdata=bookstorerepository.getallbookdata();
        for (int i=0;i<bookdata.size();i++)
        {
            List<String> tmpbook = new ArrayList<>();
            BookEntity tmpbookentity=bookdata.get(i);
            tmpbook.add(String.valueOf(tmpbookentity.getId()));
            tmpbook.add(tmpbookentity.getType());
            tmpbook.add(tmpbookentity.getName());
            tmpbook.add(tmpbookentity.getAuthor());
            tmpbook.add(String.valueOf(tmpbookentity.getPrice()));
            tmpbook.add(tmpbookentity.getImage());
            tmpbook.add(tmpbookentity.getDescription());
            data.add(tmpbook);
        }
        return data;
    }

    @RequestMapping("/adminchangedataservice")
    public Integer adminchangedataservice(@RequestParam(name = "index")Integer index, @RequestParam(name = "options")Integer options,@RequestParam(name = "content")String content)
    {
        if (options==2)
        {
            bookstorerepository.adminchangename(index,content);
        }
        if (options==3)
        {
            bookstorerepository.adminchangeauthor(index,content);
        }
        if (options==4)
        {
            bookstorerepository.adminchangeprice(index,content);
        }
        if (options==6)
        {
            bookstorerepository.adminchangedescription(index,content);
        }
        return 1;
    }

    @RequestMapping("/addcartservice")
    public Integer addcartservice(@RequestParam(name = "bookid")Integer bookid,@RequestParam(name = "username")String username)
    {
        List<BookEntity> bookdata=bookstorerepository.getusershelfdata(username);
        for (int i=0;i<bookdata.size();i++)
        {
            if (bookdata.get(i).getId()==bookid) return 0;
        }
        bookstorerepository.addcart(bookid,username);
        return 1;
    }

    @RequestMapping("/getusercartdataservice")
    public List getusercartdataservice(@RequestParam(name = "username")String username)
    {
        List<List> data=new ArrayList<>();
        List<BookEntity> bookdata=bookstorerepository.getusercartdata(username);
        for (int i=0;i<bookdata.size();i++)
        {
            List<String> tmpbook = new ArrayList<>();
            BookEntity tmpbookentity=bookdata.get(i);
            tmpbook.add(String.valueOf(tmpbookentity.getId()));
            tmpbook.add(tmpbookentity.getType());
            tmpbook.add(tmpbookentity.getName());
            tmpbook.add(tmpbookentity.getAuthor());
            tmpbook.add(String.valueOf(tmpbookentity.getPrice()));
            tmpbook.add(tmpbookentity.getImage());
            tmpbook.add(tmpbookentity.getDescription());
            data.add(tmpbook);
        }
        return data;
    }

    @RequestMapping("/userdeletecartdataservice")
    public Integer userdeletecartdataservice(@RequestParam(name = "bookid")Integer bookid,@RequestParam(name = "username")String username)
    {
        bookstorerepository.userdeletecartdata(bookid,username);
        return 1;
    }

    @RequestMapping("/usercleancartservice")
    public Integer usercleancartservice(@RequestParam(name = "username")String username)
    {
        bookstorerepository.usersetneworder(username);
        Integer neworderid=bookstorerepository.getneworderid();
        List<BookEntity> bookdata=bookstorerepository.getusercartdata(username);
        for (int i=0;i<bookdata.size();i++)
        {
            bookstorerepository.usersetneworderitem(neworderid,bookdata.get(i).getId());
            bookstorerepository.userdeletecartdata(bookdata.get(i).getId(),username);
        }
        return 1;
    }

    @RequestMapping("/getusershelfdataservice")
    public List getusershelfdataservice(@RequestParam(name = "username")String username)
    {
        List<List> data=new ArrayList<>();
        List<BookEntity> bookdata=bookstorerepository.getusershelfdata(username);
        for (int i=0;i<bookdata.size();i++)
        {
            List<String> tmpbook = new ArrayList<>();
            BookEntity tmpbookentity=bookdata.get(i);
            tmpbook.add(String.valueOf(tmpbookentity.getId()));
            tmpbook.add(tmpbookentity.getType());
            tmpbook.add(tmpbookentity.getName());
            tmpbook.add(tmpbookentity.getAuthor());
            tmpbook.add(String.valueOf(tmpbookentity.getPrice()));
            tmpbook.add(tmpbookentity.getImage());
            tmpbook.add(tmpbookentity.getDescription());
            data.add(tmpbook);
        }
        return data;
    }
}
