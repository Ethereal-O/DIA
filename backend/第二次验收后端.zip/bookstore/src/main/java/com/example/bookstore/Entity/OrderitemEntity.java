package com.example.bookstore.Entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "orderitem", schema = "mybookstore", catalog = "")
public class OrderitemEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Basic
    @Column(name = "oid")
    private int oid;
    @Basic
    @Column(name = "bid")
    private int bid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderitemEntity that = (OrderitemEntity) o;
        return id == that.id && oid == that.oid && bid == that.bid;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, oid, bid);
    }
}
