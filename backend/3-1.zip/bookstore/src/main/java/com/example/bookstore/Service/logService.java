package com.example.bookstore.Service;

public interface logService {
    public Integer checkloginservice(String username,String password);

    public Integer registerservice(String username,String password);
}
