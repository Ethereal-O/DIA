package com.example.bookstore.ServiceImpl;

import com.example.bookstore.Dao.*;
import com.example.bookstore.DaoImpl.*;
import com.example.bookstore.Entity.*;
import com.example.bookstore.Service.bookService;
import com.example.bookstore.Utils.HibernateUtil;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class bookServiceImpl implements bookService {

    @Autowired
    private BookDao bookdao;
    @Autowired
    private UserDao userdao;
    @Autowired
    private CartDao cartdao;
    @Autowired
    private OrderDao orderdao;
    @Autowired
    private OrderitemDao orderitemdao;

    private List getgetusershelfdata(String username)
    {
        UserEntity user=userdao.findUserByName(username);
        List<BookEntity> bookdata=new ArrayList<>();
        Set<OrderEntity> allorders=user.getOrders();
        for (OrderEntity order:allorders)
        {
            Set<OrderitemEntity> allorderitems=order.getOrderitems();
            for (OrderitemEntity orderitem:allorderitems)
            {
                bookdata.add(orderitem.getBook());
            }
        }
        return bookdata;
    }

    private CartEntity getgetuserdeletecart(Integer bookid,String username)
    {
        UserEntity user=userdao.findUserByName(username);
        Set<CartEntity> carts=user.getCarts();
        for (CartEntity cart:carts)
        {
            if (cart.getBook().getId()==bookid) return cart;
        }
        return null;
    }

    public List getallbookdataservice(){
        List<BookEntity> bookdata=bookdao.findallBook();
        List<List> data=new ArrayList<>();
        for (int i=0;i<bookdata.size();i++)
        {
            List<String> tmpbook = new ArrayList<>();
            BookEntity tmpbookentity=bookdata.get(i);
            tmpbook.add(String.valueOf(tmpbookentity.getId()));
            tmpbook.add(tmpbookentity.getType());
            tmpbook.add(tmpbookentity.getName());
            tmpbook.add(tmpbookentity.getAuthor());
            tmpbook.add(String.valueOf(tmpbookentity.getPrice()));
            tmpbook.add(tmpbookentity.getImage());
            tmpbook.add(tmpbookentity.getDescription());
            data.add(tmpbook);
        }
        return data;
    }


    public Integer adminchangedataservice(Integer index, Integer options, String content)
    {
        BookEntity newbook=bookdao.findBookById(index);
        if (options==2)
        {
            newbook.setName(content);
        }
        if (options==3)
        {
            newbook.setAuthor(content);
        }
        if (options==4)
        {
            newbook.setPrice(new BigDecimal(content));
        }
        if (options==6)
        {
            newbook.setDescription(content);
        }
        bookdao.updateBook(newbook);
        return 1;
    }


    public Integer addcartservice(Integer bookid,String username)
    {
        List<BookEntity> bookdata=getgetusershelfdata(username);
        UserEntity user=userdao.findUserByName(username);
        Set<CartEntity> carts=user.getCarts();
        for (CartEntity cart:carts)
        {
            bookdata.add(cart.getBook());
        }
        for (int i=0;i<bookdata.size();i++)
        {
            if(bookdata.get(i).getId()==bookid) return 0;
        }

        CartEntity newcart=new CartEntity();
        newcart.setBook(bookdao.findBookById(bookid));
        newcart.setUser(userdao.findUserByName(username));
        cartdao.addCart(newcart);
        return 1;
    }


    public List getusercartdataservice(String username)
    {
        UserEntity user=userdao.findUserByName(username);
        Set<CartEntity> carts=user.getCarts();
        List<BookEntity> bookdata = new ArrayList<BookEntity>();
        for (CartEntity cart:carts)
        {
            bookdata.add(cart.getBook());
        }
        List<List> data=new ArrayList<>();
        for (int i=0;i<bookdata.size();i++)
        {
            List<String> tmpbook = new ArrayList<>();
            BookEntity tmpbookentity=bookdata.get(i);
            tmpbook.add(String.valueOf(tmpbookentity.getId()));
            tmpbook.add(tmpbookentity.getType());
            tmpbook.add(tmpbookentity.getName());
            tmpbook.add(tmpbookentity.getAuthor());
            tmpbook.add(String.valueOf(tmpbookentity.getPrice()));
            tmpbook.add(tmpbookentity.getImage());
            tmpbook.add(tmpbookentity.getDescription());
            data.add(tmpbook);
        }
        return data;
    }


    public Integer userdeletecartdataservice(Integer bookid,String username)
    {
        cartdao.deleteCart(getgetuserdeletecart(bookid,username));
        return 1;
    }


    public Integer usercleancartservice(String username)
    {
        UserEntity user=userdao.findUserByName(username);
        OrderEntity neworder=new OrderEntity();
        neworder.setUser(user);
        orderdao.addOrder(neworder);
        Set<CartEntity> carts=user.getCarts();
        for (CartEntity cart:carts)
        {
            OrderitemEntity neworderitem=new OrderitemEntity();
            neworderitem.setOrder(neworder);
            neworderitem.setBook(cart.getBook());
            orderitemdao.addOrderitem(neworderitem);
            cartdao.deleteCart(cart);
        }
        return 1;
    }


    public List getusershelfdataservice(String username)
    {
        List<BookEntity> bookdata=getgetusershelfdata(username);
        List<List> data=new ArrayList<>();
        for (int i=0;i<bookdata.size();i++)
        {
            List<String> tmpbook = new ArrayList<>();
            BookEntity tmpbookentity=bookdata.get(i);
            tmpbook.add(String.valueOf(tmpbookentity.getId()));
            tmpbook.add(tmpbookentity.getType());
            tmpbook.add(tmpbookentity.getName());
            tmpbook.add(tmpbookentity.getAuthor());
            tmpbook.add(String.valueOf(tmpbookentity.getPrice()));
            tmpbook.add(tmpbookentity.getImage());
            tmpbook.add(tmpbookentity.getDescription());
            data.add(tmpbook);
        }
        return data;
    }
}
