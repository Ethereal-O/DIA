package com.example.bookstore.Entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "`order`", schema = "mybookstore", catalog = "")
public class OrderEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;


    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="uid")
    private UserEntity user;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public UserEntity getUser()
    {
        return user;
    }

    public void setUser(UserEntity user) {
        this.user = user;
    }

//    @Transient
    @OneToMany(cascade = CascadeType.ALL,
        mappedBy = "order", orphanRemoval = true,fetch=FetchType.EAGER)
    private Set<OrderitemEntity> orderitems;
    public Set<OrderitemEntity> getOrderitems(){return orderitems;}
    public void setOrderitems(Set<OrderitemEntity> neworderitems){this.orderitems=neworderitems;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderEntity that = (OrderEntity) o;
        return id == that.id && user == that.user;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, user);
    }
}
