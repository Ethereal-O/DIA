package com.example.bookstore.ServiceImpl;

import com.example.bookstore.Dao.UserDao;
import com.example.bookstore.DaoImpl.UserDaoImpl;
import com.example.bookstore.Entity.UserEntity;
import com.example.bookstore.Service.logService;
import com.example.bookstore.Utils.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class logServiceImpl implements logService {

    @Autowired
    private UserDao userdao;
    public Integer checkloginservice(String username, String password){
        UserEntity user=userdao.findUserByName(username);
        if (user==null) return -1;
        if (Objects.equals(user.getPassword(), password))
        {
            SessionUtil.SetSession(user.getId(),user.getType());
            return user.getType();
        }
        return 0;
    }

    @Override
    public boolean trylogoutservice() {
        return SessionUtil.RemoveSession();
    }

    public Integer registerservice(String username, String password)
    {
        UserEntity user=userdao.findUserByName(username);
        if (user!=null) return 0;
        UserEntity newuser=new UserEntity();
        newuser.setUsername(username);
        newuser.setPassword(password);
        newuser.setType(1);
        userdao.addUser(newuser);
        return 1;
    }
}
