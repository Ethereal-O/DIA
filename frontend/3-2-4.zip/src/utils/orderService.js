import {postrequest} from "./ajax";

export const checkloginservice=(checkdata,callback)=>{
    const url="http://localhost:8080/checkloginservice";
    postrequest(url,checkdata,callback);
}

export const trylogoutservice=(callback)=>{
    const url="http://localhost:8080/trylogoutservice";
    postrequest(url,null,callback);
}

export function registerservice(registerdata,callback)
{
    const url="http://localhost:8080/registerservice";
    postrequest(url,registerdata,callback);
}

export function getallbookdataservice(callback)
{
    const url="http://localhost:8080/getallbookdataservice";
    postrequest(url,null,callback);
}

export function addcartservice(addcartdata,callback)
{
    const url="http://localhost:8080/addcartservice";
    postrequest(url,addcartdata,callback);
}

export function adminchangedataservice(admindata,callback)
{
    const url="http://localhost:8080/adminchangedataservice";
    postrequest(url,admindata,callback);
}

export function admindeletebookservice(list,callback)
{
    const url="http://localhost:8080/admindeletebookservice";
    postrequest(url,list,callback);
}

export function adminaddbookservice(list,callback)
{
    const url="http://localhost:8080/adminaddbookservice";
    postrequest(url,list,callback);
}

export function getusercartdataservice(username,callback)
{
    const url="http://localhost:8080/getusercartdataservice";
    postrequest(url,username,callback);
}

export function userdeletecartdataservice(deletedata,callback)
{
    const url="http://localhost:8080/userdeletecartdataservice";
    postrequest(url,deletedata,callback);
}

export function usercleancartservice(username,callback)
{
    const url="http://localhost:8080/usercleancartservice";
    postrequest(url,username,callback);
}

export function getusershelfdataservice(username,callback)
{
    const url="http://localhost:8080/getusershelfdataservice";
    postrequest(url,username,callback);
}

export function getalluserdataservice(callback)
{
    const url="http://localhost:8080/getalluserdataservice";
    postrequest(url,null,callback);
}

export function adminchangeuserdataservice(admindata,callback)
{
    const url="http://localhost:8080/adminchangeuserdataservice";
    postrequest(url,admindata,callback);
}

export function admindeleteuserdataservice(list,callback)
{
    const url="http://localhost:8080/admindeleteuserdataservice";
    postrequest(url,list,callback);
}

export function getallorderdataservice(callback)
{
    const url="http://localhost:8080/getallorderdataservice";
    postrequest(url,null,callback);
}

export function adminaddorderservice(adminaddorderdata,callback)
{
    const url="http://localhost:8080/adminaddorderservice";
    postrequest(url,adminaddorderdata,callback);
}

export function admindeleteorderservice(admindeleteorderdata,callback)
{
    const url="http://localhost:8080/admindeleteorderservice";
    postrequest(url,admindeleteorderdata,callback);
}