import React from 'react';
import '../css/statistics.css';

export class Statisticscontainer extends React.Component{

    data=[];
    constructor(props){
        super(props);
        // this.data=props.data;
        this.state={
            alldata:props.data,
        }
    }
    componentWillReceiveProps(nextProps){
        this.setState({
            alldata:nextProps.data,
        })
    }

    updatealldata(){
        this.props.parent.updatealldata();
    }

    render(){
        return(
            <div className="statisticscontainer">
                <div className="card">
                </div>
            </div>
        )
    }
}
