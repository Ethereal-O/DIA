import React from 'react';
import { Router, Route, Switch, Redirect} from 'react-router-dom';
import {history} from "./utils/history";
import Home from "./view/home";
import Allbooks from "./view/allbooks";
import Mybooks from "./view/mybooks";
import Mycarts from './view/mycarts';

class BasicRoute extends React.Component{

    constructor(props) {
        super(props);

        history.listen((location, action) => {
            // clear alert on location change
            console.log(location,action);
        });
    }

    render(){
        return(
            <Router history={history}>
                <Switch>
                    <Route exact path="/" component={Home} />
                    <Route exact path="/Allbooks" component={Allbooks} />
                    <Route exact path="/Mybooks" component={Mybooks} />
                    <Route exact path="/Mycarts" component={Mycarts} />
                    <Redirect from="/*" to="/" />
                </Switch>

            </Router>
        )
    }


}

export default BasicRoute;