import React from "react";
import '../css/mybooks.css'
import '../css/allbooks.css'
import '../css/mycarts.css'

export class NameList extends React.Component{

    render(){
        if (this.props.options==="books")
        {
            return(
                <div className="name" id="namelist">
                    <div className="nameelement" onClick={(e) => this.props.parent.datasort(e)} id="nametitle">
                        <h2>Name</h2>
                    </div>
                    {
                        this.props.ele.map(item => (
                            <button id={"btn" + item[0]} onClick={(e) => this.props.parent.Showdetails(e)} className="nameelement">
                                <p>{item[2]}</p>
                            </button>
                        ))
                    }
                </div>
            )
        }
        else
        {
            return(
                <div className="name" id="namelist">
                    <div className="nameandpricetitle" id="nametitle">
                        <h2>Name</h2><h2>Price</h2>
                    </div>
                    {
                        this.props.ele.map(item => (
                            <button id={"btn" + item[0]} onClick={(e) => this.props.parent.Showdetails(e)} className="nameandpriceelement">
                                <div className="nameandprice">
                                    <p>{item[2]}</p>
                                    <p>{item[4]} dollars</p>
                                </div>
                            </button>
                        ))
                    }
                </div>
            )
        }
        
    }
}