import * as Orderservice from "../utils/orderService";

//home
export function checklogin(username,password,checklogincallback) // 返回2管理员，1普通用户，0密码错误，-1无用户
{
    let checkdata=new FormData();
    checkdata.append("username",username);
    checkdata.append("password",password);
    Orderservice.checkloginservice(checkdata, checklogincallback);
}

export function trylogout(logoutcallback)
{
    Orderservice.trylogoutservice(logoutcallback);
}

export function register(username,password,registercallback) // 返回1普通用户，0已注册，-1失败
{
    let registerdata=new FormData();
    registerdata.append("username",username);
    registerdata.append("password",password);
    Orderservice.registerservice(registerdata,registercallback);
}

// allbook
export function getallbookdata(getallbookdatacallback)
{
    // let data=[[0,"HP","HP and PS","J.K.RowLing","100","hp_and_ps","Harry Potter and the Philosopher Stone Sorcerer's Stone."],[1,"HP","HP and GF","J.K.RowLing","100","hp_and_gf","Harry Potter and the Goblet of Fire."],[2,"CS","CSAPP","Randal E.Bryant / David O'Hallaron","200","csapp","Computer Systems: A Programmer's Perspective."]];
    // return data;
    Orderservice.getallbookdataservice(getallbookdatacallback);
}

export function adminchangedata(index, options,content,adminchangedatacallback)
{
    if (index===-1) return;
    // return 1;
    let admindata=new FormData();
    admindata.append("index",index);
    admindata.append("options",options);
    admindata.append("content",content);
    Orderservice.adminchangedataservice(admindata,adminchangedatacallback);
}

export function addcart(bookid,username,addcartcallback)
{
    if (bookid===-1) return;
    // return 1;
    let addcartdata=new FormData();
    addcartdata.append("bookid",bookid);
    addcartdata.append("username",username);
    Orderservice.addcartservice(addcartdata,addcartcallback);
}

// cart
export function getusercartdata(username,getusercartdatacallback)
{
    // let data=[[0,"HP","HP and PS","J.K.RowLing","100","hp_and_ps","Harry Potter and the Philosopher Stone Sorcerer's Stone."],[1,"HP","HP and GF","J.K.RowLing","100","hp_and_gf","Harry Potter and the Goblet of Fire."],[2,"CS","CSAPP","Randal E.Bryant / David O'Hallaron","200","csapp","Computer Systems: A Programmer's Perspective."]];
    // return data;
    let list=new FormData();
    list.append("username",username);
    Orderservice.getusercartdataservice(list,getusercartdatacallback);
}

export function userdeletecartdata(bookid,username,userdeletecartdatacallback)
{
    if (bookid===-1)return;
    // return 1;
    let deletedata=new FormData();
    deletedata.append("bookid",bookid);
    deletedata.append("username",username);
    Orderservice.userdeletecartdataservice(deletedata,userdeletecartdatacallback);
}

export function usercleancart(username,usercleancartcallback)
{
    // return 1;
    let list=new FormData();
    list.append("username",username);
    Orderservice.usercleancartservice(list,usercleancartcallback);
}

// shelf
export function getusershelfdata(username,getusershelfdatacallback)
{
    // let data=[[0,"HP","HP and PS","J.K.RowLing","100","hp_and_ps","Harry Potter and the Philosopher Stone Sorcerer's Stone."],[1,"HP","HP and GF","J.K.RowLing","100","hp_and_gf","Harry Potter and the Goblet of Fire."],[2,"CS","CSAPP","Randal E.Bryant / David O'Hallaron","200","csapp","Computer Systems: A Programmer's Perspective."]];
    // return data;
    let list=new FormData();
    list.append("username",username);
    Orderservice.getusershelfdataservice(list,getusershelfdatacallback);
}