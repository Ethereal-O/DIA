import React from "react";
import '../css/mybooks.css'
import '../css/allbooks.css'

export class Searchbar extends React.Component{

    render(){
        return(
            <div className="searchbar">
                <form>
                    <input className="searchdata" id="searchdata" type="text" name="searchdata"></input>
                    <input className="searchbutton" type="button" value="Search" onClick={() => this.props.parent.searchdata()} />
                </form>
            </div>
        )
    }
}