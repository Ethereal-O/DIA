import React from 'react';
import '../css/allusers.css';
import {withRouter} from "react-router-dom";
import { Alluserscontainer} from '../components/alluserscomponents';
import { getalluserdata } from '../components/connect_to_backend';

class Allusers extends React.Component{

    //User data
    data=[];
    constructor(){
        super();
        getalluserdata(this.getalluserdatacallback);
        this.state={
            alldata:this.data
        }
    }

    getalluserdatacallback=(data)=>
    {
        console.log(data);
        this.setState({
            alldata:data
        })
    }

    updatealldata(){
        getalluserdata(this.getalluserdatacallback);
    }

    render(){
        return(
            <div className="allusersmain">
                <div className="header">Here are all users.</div>
                <Alluserscontainer parent={this} data={this.state.alldata}></Alluserscontainer>
            </div>
        )
    }
}

export default withRouter(Allusers);